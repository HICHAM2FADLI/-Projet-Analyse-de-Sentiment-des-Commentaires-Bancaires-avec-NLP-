import pandas as pd
import psycopg2
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from datetime import datetime

# Function to load data from Excel file to PostgreSQL
def load_data_to_postgresql():
    excel_file_path = "/Users/habibaezzagrani/Desktop/DMProject/CIHTotalScore.xlsx"
    table_name = "cityDimension"
    
    # Load Excel data into a pandas DataFrame
    df = pd.read_excel(excel_file_path)
    
    # Create a database connection
    conn = psycopg2.connect(
        host="localhost",
        database="cihdatawarehouse",
        user="habibaezzagrani",
        password="",
        port="5432"
    )
    
    try:
        # Create a cursor object
        cur = conn.cursor()
        
        # Create the table in PostgreSQL
        cur.execute(f"CREATE TABLE IF NOT EXISTS {table_name} (id SERIAL PRIMARY KEY, city TEXT)")
        
        # Convert DataFrame columns to a list of tuples
        records = df.to_records(index=False)
        values = list(records)
        
        # Create the insert query
        insert_query = f"INSERT INTO {table_name} (city) VALUES (%s)"
        
        # Execute the insert query with the DataFrame values
        cur.executemany(insert_query, values)
        
        # Commit the changes to the database
        conn.commit()
        
        print("Data loaded successfully to PostgreSQL!")
    
    except (Exception, psycopg2.DatabaseError) as error:
        print("Error loading data to PostgreSQL:", error)
    
    finally:
        # Close the cursor and database connection
        cur.close()
        conn.close()

# Define the Airflow DAG
dag = DAG(
    'excel_to_postgresql',
    description='Load data from Excel to PostgreSQL',
    schedule_interval=None,
    start_date=datetime(2023, 6, 7),
    catchup=False
)

# Define the PythonOperator to execute the data loading function
load_data_task = PythonOperator(
    task_id='load_data_to_postgresql',
    python_callable=load_data_to_postgresql,
    dag=dag
)

# Set the task dependency
load_data_task
